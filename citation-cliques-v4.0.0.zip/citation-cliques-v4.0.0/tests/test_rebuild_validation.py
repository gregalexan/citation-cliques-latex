import sqlite3
import unittest

import rebuild_analysis_database as rebuild


class MatchedCohortValidationTests(unittest.TestCase):
    def test_h5_caliper_is_inclusive_and_enforced(self) -> None:
        for difference, accepted in ((3, True), (4, False)):
            with self.subTest(difference=difference):
                connection = sqlite3.connect(":memory:")
                self.addCleanup(connection.close)
                connection.execute("ATTACH DATABASE ':memory:' AS rolap")
                connection.executescript(
                    """
                    CREATE TABLE rolap.author_matched_pairs (
                      case_orcid TEXT, control_orcid TEXT, subject TEXT
                    );
                    INSERT INTO rolap.author_matched_pairs VALUES ('A', 'B', 'S');
                    CREATE TABLE rolap.author_subject_h5_index (
                      orcid TEXT, subject TEXT, h5_index INTEGER
                    );
                    INSERT INTO rolap.author_subject_h5_index VALUES ('A', 'S', 10);
                    """
                )
                connection.execute(
                    "INSERT INTO rolap.author_subject_h5_index VALUES ('B', 'S', ?)",
                    (10 + difference,),
                )
                if accepted:
                    self.assertEqual(rebuild.validate_matched_cohort(connection), 1)
                else:
                    with self.assertRaisesRegex(RuntimeError, "failed validation"):
                        rebuild.validate_matched_cohort(connection)

    def test_nonpositive_h5_is_rejected(self) -> None:
        connection = sqlite3.connect(":memory:")
        self.addCleanup(connection.close)
        connection.execute("ATTACH DATABASE ':memory:' AS rolap")
        connection.executescript(
            """
            CREATE TABLE rolap.author_matched_pairs (
              case_orcid TEXT, control_orcid TEXT, subject TEXT
            );
            INSERT INTO rolap.author_matched_pairs VALUES ('A', 'B', 'S');
            CREATE TABLE rolap.author_subject_h5_index (
              orcid TEXT, subject TEXT, h5_index INTEGER
            );
            INSERT INTO rolap.author_subject_h5_index VALUES
              ('A', 'S', 0),
              ('B', 'S', 0);
            """
        )
        with self.assertRaisesRegex(RuntimeError, "failed validation"):
            rebuild.validate_matched_cohort(connection)

    def test_empty_cohort_is_rejected(self) -> None:
        connection = sqlite3.connect(":memory:")
        self.addCleanup(connection.close)
        connection.execute("ATTACH DATABASE ':memory:' AS rolap")
        connection.executescript(
            """
            CREATE TABLE rolap.author_matched_pairs (
              case_orcid TEXT, control_orcid TEXT, subject TEXT
            );
            CREATE TABLE rolap.author_subject_h5_index (
              orcid TEXT, subject TEXT, h5_index INTEGER
            );
            """
        )
        with self.assertRaisesRegex(RuntimeError, "failed validation"):
            rebuild.validate_matched_cohort(connection)


if __name__ == "__main__":
    unittest.main()
